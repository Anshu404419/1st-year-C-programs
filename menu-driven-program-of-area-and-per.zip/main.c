#include <stdio.h>
#include <math.h>
int main()
{
    int ch;
    float length,breadth,radius,side,a,b,c,s,area,peri;
    printf("Menu Driven Program\n");
    printf("Area and Perimater of:-\n1.square\n2.rectangle\n3.circle\n4.triangle\n");
    printf("Enter your choice\n");
    scanf("%d",&ch);
    switch(ch)
    {
        case 1:
            printf("Enter side of a square\n");
            scanf("%f", &side);
            peri=4*side;
            printf("perimeter=%f\n", peri);
    
            area=side*side;
            printf("Area=%f", area);
            break;
            
        case 2:
            printf("Enter length of rectangle\n");
            scanf("%f", &length);
    
            printf("Enter bredth of rectangle\n");
            scanf("%f", &breadth);
            area=length*breadth;
            printf("area=%f\n", area);
    
            peri=2*(length+breadth);
            printf("perimeter=%f", peri);
            break;
        
        case 3:
            printf("Enter radius of cicle\n");
            scanf("%f",&radius);
            area=3.14*radius*radius;
            peri=2*3.14*radius;
            printf("Area=%f\n",area);
            printf("peri=%f",peri);
            break;
        
        case 4:
            printf("Enter first side of trinagle\n");
            scanf("%f", &a);
            printf("Enter second side of triangle\n");
            scanf("%f", &b);
            printf("Enter third side of triangle\n");
            scanf("%f", &c);
            
    
            s=(a+b+c)/2;
    
            area=sqrt(s*(s-a)*(s-b)*(s-c));
            printf("Area=%f\n", area);
    
            peri=a+b+c;
            printf("Perimeter of triangle=%f\n",peri);
            break;
        return 0;    
    }
}