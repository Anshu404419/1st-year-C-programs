#include <stdio.h>

int main()
{
    int a,b,c,d,e,sum;
    printf("Enter a three digit number\n");
    scanf("%d",&a);
    b=a%10;
    c=a/10;
    d=c%10;
    e=c/10;
    sum=b*b*b+d*d*d+e*e*e;
    if (sum==a)
        printf("%d is armstrong\n",a);
    else
        printf("%d is not armstrong\n",a);
    return 0;
}