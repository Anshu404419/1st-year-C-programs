#include <stdio.h>

int main()
{
	int a,b;
	printf("Enter any two numbers\n");
	scanf("%d %d", &a, &b);
	a= a+b;
	b= a-b;
	a= a-b;
	printf("Swapped numbers are\na=%d\nb=%d\n",a,b);
	return 0;
}