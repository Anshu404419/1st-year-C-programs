
#include <stdio.h>
#include <conio.h>

int main()
{
    int ch;
    float radius, vol, height, side, length, breadth;
    printf("Menu Driven Program\n");
    printf("Volume of:- \n1.Cylinder\n2.Cube\n3.Cuboid\n4.Sphere\n5.Cone\n");
    printf("Enter your choice\n");
    scanf("%d",&ch);
    switch(ch)
    {
        case 1:
            printf("Enter height of the cylinder\n");
            scanf("%f",&height);
            printf("Enter radius of the cylinder\n");
            scanf("%f",&radius);
            vol=3.14*radius*radius*height;
            printf("volume of cylinder=%f",vol);
            break;
            
        case 2:
            printf("Enter side of cube\n");
            scanf("%f",&side);
            vol=side*side*side;
            printf("Volume of cube=%f",vol);
            break;
            
        case 3:
            printf("Enter length of cuboid\n");
            scanf("%f",&length);
            printf("Enter breadth of cuboid\n");
            scanf("%f",&breadth);
            printf("Enter height of cuboid\n");
            scanf("%f",&height);
            vol=length*breadth*height;
            printf("Volume of cuboid=%f",vol);
            break;
        
        case 4:
            printf("Enter radius of the sphere\n");
            scanf("%f",&radius);
            vol=1.333*3.14*radius*radius*radius;
            printf("Volume of sphere=%f", vol);
            break;
            
        case 5:
            printf("Enter height of the cone\n");
            scanf("%f",&height);
            printf("Enter radius of the cone\n");
            scanf("%f",&radius);
            vol=0.333*3.14*radius*radius*height;
            printf("Volume of the cone=%f",vol);
            break;
        return 0;  
    }
    
}
 