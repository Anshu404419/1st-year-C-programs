#include <stdio.h>

int main()
{
    int a,b,c,d,e,f,g;
    printf("Enter any two number\n");
    scanf("%d%d", &a, &b);
    c=a+b;
    printf("sum = %d\n", c);
    d=a-b;
    printf("Subtract = %d\n", d);
    e=a*b;
    printf("product = %d\n", e);
    f=a/b;
    printf("divide = %d\n", f);
    g=a%b;
    printf("modulo = %d\n", g);
    
    return 0;
}