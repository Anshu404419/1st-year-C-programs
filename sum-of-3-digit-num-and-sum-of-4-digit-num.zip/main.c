/*#include <stdio.h>

int main()
{
	int a,c,d,e,f,g;
	printf("Enter any three digit number\n");
	scanf("%d",&a);
	c=a%10; //ones place
	d=a/10;
	e=d%10; //tens place
	f=d/10; //hundreadths place
	g=c+e+f;
	printf("Sum of the digits of the number is %d",g);
	return 0;
}*/
#include <stdio.h>
int main()
{
    int a,c,d,e,f,g,h,i;
	printf("Enter any four digit number\n");
	scanf("%d",&a);
	c=a%10; //ones place
	d=a/10;
	e=d%10; //tens place
	f=d/10; 
	g=f%10; //hundreadths place
	h=f/10; //thousands place
	i=c+e+g+h;
	printf("Sum of the digits of the number is %d",i);
	return 0;
}


