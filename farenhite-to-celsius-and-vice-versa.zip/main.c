#include <stdio.h>
int main()
{
    int ch;
    float celsius, farenhite;
    printf("Menu Driven Program\n");
    printf("1.Farenhtie to Celsius\n2.Celsius to Farenhite\n");
    printf("Enter your choice\n");
    scanf("%d",&ch);
    switch(ch)
    {
        case 1:
            printf("Enter the temperature in farenhite\n");
            scanf("%f",&farenhite);
            celsius=0.556*(farenhite-32);
            printf("Temperature in celsius=%f",celsius);
            break;
            
        case 2:
            printf("Enter temperature in celsius\n");
            scanf("%f",&celsius);
            farenhite=(1.8*celsius)+32;
            printf("Temperature in farenhite=%f",farenhite);
            break;
        return 0;
    }
}
