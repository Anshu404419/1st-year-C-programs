#include <stdio.h>
#include <math.h>
int main()
{
    int principal, rate, Time, SI;
    printf("Enter principal amount\n");
    scanf("%d",&principal);
    printf("Enter Rate\n");
    scanf("%d",&rate);
    printf("Enter Time\n");
    scanf("%d",&Time);
    SI=(principal*rate*Time)/100;
    printf("Simple Intrest is=%d\n", SI);
    return 0;
}
/*
#include <stdio.h>
#include <math.h>
int main()
{
        int principal, rate, Time, n, CI, x;
        printf("Enter principal amount\n");
        scanf("%d",&principal);
        printf("Enter Rate\n");
        scanf("%d",&rate);
        printf("Enter Time\n");
        scanf("%d",&Time);
        printf("Enter number of times intrest is compounded per year\n");
        scanf("%d",&n);
        CI=principal*pow((1+rate/n), n*Time);
        printf("Compound Intrest is =%d", CI);
        return 0;
}*/

     
