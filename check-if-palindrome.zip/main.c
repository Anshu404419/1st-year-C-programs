#include <stdio.h>

int main()
{
    int a,b,c,d,e,sum,rev;
    printf("Enter a three digit number\n");
    scanf("%d",&a);
    b=a%10;//one
    c=a/10;
    d=c%10;//tens
    e=c/10;//100
    sum=b*100+d*10+e*1;
    if (sum==a)
        printf("%d is a palindrome",sum);
    else
        printf("%d is not a palindrome",sum);
    return 0;
}