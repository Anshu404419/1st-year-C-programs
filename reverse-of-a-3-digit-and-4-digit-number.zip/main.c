
/*#include <stdio.h>

int main()
{
    int a,b,c,d,e,f,g,h;
    printf("Enter a three digit number\n");
    scanf("%d",&a);
    b=a%10;//ones
    c=a/10;
    d=c%10;//tens
    e=c/10;//hundreadths
    f=b;
    g=d;
    h=e;
    printf("Reverse of the number is %d%d%d\n",f,g,h);
    return 0;
}*/

#include <stdio.h>
int main()
{
    int a,c,d,e,f,g,h,i,j,k,l;
	printf("Enter any four digit number\n");
	scanf("%d",&a);
	c=a%10; //ones place
	d=a/10;
	e=d%10; //tens place
	f=d/10; 
	g=f%10; //hundreadths place
	h=f/10; //thousands place
	i=c;
	j=e;
	k=g;
	l=h;
	printf("Reverse of the number is %d%d%d%d\n",i,j,k,l);
	return 0;
}